f = open("DataExtracted.txt","r")
text = f.read().splitlines()
locations = []
# Store latitude and longitude in a .csv file
for i in text:
 string = i.replace(" HTTP/1.1 ","\n")
 string = string.replace("%2C",",")
 split = string.split("location=")
 locations.append(split[1])
output = open("ExtractedCoordinates.csv","w")
output.write("Latitude,Longitude\n")
for i in locations:
 output.write(i)
output.close()